package com.freelancer.RealEstate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealEstateApplicationTests {

	@Test
	void contextLoads() {
	}

}
