package com.freelancer.RealEstate.controller;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;


import java.io.IOException;
import java.sql.SQLException;



class PropertyControllerTest {

    @InjectMocks
    private PropertyController propertyController;

    @Test
    void addProperty() {
    }

    @Test
    void getProperties() {
    }

    @Test
    void getPropertyByPropertyId() throws SQLException, IOException {

    }
}